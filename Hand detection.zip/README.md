# Handdetection

# @todo
В Кванториуме сделать

pip freeze > requirements.txt

положить requirements.txt в репозиторий, чтобы дома можно было сделать

pip install -r requirements.txt
